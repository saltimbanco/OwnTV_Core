package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.ReminderEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class ReminderDao_Impl(
  __db: RoomDatabase,
) : ReminderDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfReminderEntity: EntityInsertAdapter<ReminderEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfReminderEntity = object : EntityInsertAdapter<ReminderEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `programme_reminders` (`id`,`profileId`,`channelId`,`channelName`,`epgChannelId`,`title`,`startMs`,`stopMs`,`leadMinutes`,`createdAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ReminderEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        statement.bindLong(3, entity.channelId)
        statement.bindText(4, entity.channelName)
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpEpgChannelId)
        }
        statement.bindText(6, entity.title)
        statement.bindLong(7, entity.startMs)
        statement.bindLong(8, entity.stopMs)
        statement.bindLong(9, entity.leadMinutes.toLong())
        statement.bindLong(10, entity.createdAt)
      }
    }
  }

  public override suspend fun upsert(reminder: ReminderEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfReminderEntity.insertAndReturnId(_connection, reminder)
    _result
  }

  public override suspend fun getById(id: Long): ReminderEntity? {
    val _sql: String = "SELECT * FROM programme_reminders WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfLeadMinutes: Int = getColumnIndexOrThrow(_stmt, "leadMinutes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: ReminderEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpLeadMinutes: Int
          _tmpLeadMinutes = _stmt.getLong(_columnIndexOfLeadMinutes).toInt()
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _result = ReminderEntity(_tmpId,_tmpProfileId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpStartMs,_tmpStopMs,_tmpLeadMinutes,_tmpCreatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeForProfile(profileId: Long): Flow<List<ReminderEntity>> {
    val _sql: String = "SELECT * FROM programme_reminders WHERE profileId = ? ORDER BY startMs ASC"
    return createFlow(__db, false, arrayOf("programme_reminders")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfLeadMinutes: Int = getColumnIndexOrThrow(_stmt, "leadMinutes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<ReminderEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReminderEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpLeadMinutes: Int
          _tmpLeadMinutes = _stmt.getLong(_columnIndexOfLeadMinutes).toInt()
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = ReminderEntity(_tmpId,_tmpProfileId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpStartMs,_tmpStopMs,_tmpLeadMinutes,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<ReminderEntity> {
    val _sql: String = "SELECT * FROM programme_reminders ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfLeadMinutes: Int = getColumnIndexOrThrow(_stmt, "leadMinutes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<ReminderEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReminderEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpLeadMinutes: Int
          _tmpLeadMinutes = _stmt.getLong(_columnIndexOfLeadMinutes).toInt()
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = ReminderEntity(_tmpId,_tmpProfileId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpStartMs,_tmpStopMs,_tmpLeadMinutes,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAll(): Flow<List<ReminderEntity>> {
    val _sql: String = "SELECT * FROM programme_reminders ORDER BY startMs ASC"
    return createFlow(__db, false, arrayOf("programme_reminders")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfLeadMinutes: Int = getColumnIndexOrThrow(_stmt, "leadMinutes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<ReminderEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReminderEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpLeadMinutes: Int
          _tmpLeadMinutes = _stmt.getLong(_columnIndexOfLeadMinutes).toInt()
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = ReminderEntity(_tmpId,_tmpProfileId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpStartMs,_tmpStopMs,_tmpLeadMinutes,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(id: Long) {
    val _sql: String = "DELETE FROM programme_reminders WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteEnded(now: Long): Int {
    val _sql: String = "DELETE FROM programme_reminders WHERE stopMs <= ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, now)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
